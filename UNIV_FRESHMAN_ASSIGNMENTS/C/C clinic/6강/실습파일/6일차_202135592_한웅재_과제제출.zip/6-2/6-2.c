#define _CRT_SECURE_NO_WARNINGS// or scanf_s
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
int main(void)
{
	char name[20];
	printf("�̸��� �Է��ϼ��� :");
	gets(name);
	puts(name);
}








